// Home page functionality
document.addEventListener('DOMContentLoaded', () => {
    updateReadiness();
    updateQuickStats();
    initMetricsLab();
    initDailyChallenge();
});

function updateReadiness() {
    const progress = APUSH.getUserProgress();
    const overallMastery = APUSH.calculateOverallMastery();
    
    const percentageEl = document.getElementById('readiness-percentage');
    const progressEl = document.getElementById('readiness-progress');
    
    if (percentageEl) {
        percentageEl.textContent = `${overallMastery}%`;
    }
    
    if (progressEl) {
        progressEl.style.width = `${overallMastery}%`;
        progressEl.setAttribute('aria-valuenow', overallMastery);
    }
}

function updateQuickStats() {
    const progress = APUSH.getUserProgress();
    
    // Count completed periods
    const completedPeriods = Object.values(progress.periods).filter(p => p.completed).length;
    
    // Get practice questions count
    const practiceQuestions = progress.practiceQuestions || 0;
    
    // Get study hours (convert from minutes or use stored value)
    const studyHours = Math.round((progress.studyHours || 0) / 60);
    
    const periodsEl = document.getElementById('periods-completed');
    const questionsEl = document.getElementById('practice-questions');
    const hoursEl = document.getElementById('study-hours');
    
    if (periodsEl) periodsEl.textContent = completedPeriods;
    if (questionsEl) questionsEl.textContent = practiceQuestions;
    if (hoursEl) hoursEl.textContent = studyHours;
}

function initMetricsLab() {
    const hoursInput = document.getElementById('hours-input');
    const accuracyInput = document.getElementById('accuracy-input');
    const engagementInput = document.getElementById('engagement-input');

    if (!hoursInput || !accuracyInput || !engagementInput) {
        return;
    }

    const hoursOutput = document.getElementById('hours-output');
    const accuracyOutput = document.getElementById('accuracy-output');
    const engagementOutput = document.getElementById('engagement-output');

    const projectedScore = document.getElementById('projected-score');
    const metricStreak = document.getElementById('metric-streak');
    const metricCompletion = document.getElementById('metric-completion');
    const metricAttendance = document.getElementById('metric-attendance');
    const projectedNote = document.getElementById('projected-note');

    const updateOutputs = () => {
        const hours = Number(hoursInput.value);
        const accuracy = Number(accuracyInput.value);
        const engagement = Number(engagementInput.value);

        if (hoursOutput) hoursOutput.textContent = String(hours);
        if (accuracyOutput) accuracyOutput.textContent = String(accuracy);
        if (engagementOutput) engagementOutput.textContent = String(engagement);

        // Weighted readiness model with bounded range for demo consistency
        const readiness = clamp(Math.round((hours * 3.2) + (accuracy * 0.5) + (engagement * 0.3)), 35, 99);
        const streak = clamp(Math.round((accuracy * 0.65) + (engagement * 0.25) + (hours * 1.2)), 20, 98);
        const completion = clamp(Math.round((hours * 4.8) + (accuracy * 0.32) + (engagement * 0.2)), 18, 97);
        const attendance = clamp(Math.round((engagement * 0.8) + (hours * 2.4)), 10, 99);

        if (projectedScore) projectedScore.textContent = `${readiness}%`;
        if (metricStreak) metricStreak.textContent = `${streak}%`;
        if (metricCompletion) metricCompletion.textContent = `${completion}%`;
        if (metricAttendance) metricAttendance.textContent = `${attendance}%`;

        if (!projectedNote) return;
        if (readiness >= 90) {
            projectedNote.textContent = 'Excellent trajectory. Keep attendance high and focus on document analysis depth.';
        } else if (readiness >= 80) {
            projectedNote.textContent = 'Strong trajectory. Add one focused writing session per week to accelerate gains.';
        } else if (readiness >= 70) {
            projectedNote.textContent = 'Solid baseline. Increase weekly hours and review missed concepts in weak themes.';
        } else {
            projectedNote.textContent = 'Growth phase. Start with shorter daily sessions and prioritize high-impact practice sets.';
        }
    };

    hoursInput.addEventListener('input', updateOutputs);
    accuracyInput.addEventListener('input', updateOutputs);
    engagementInput.addEventListener('input', updateOutputs);
    updateOutputs();
}

function initDailyChallenge() {
    const challengeButton = document.getElementById('generate-focus-btn');
    const challengeOutput = document.getElementById('focus-challenge');

    if (!challengeButton || !challengeOutput) {
        return;
    }

    const prompts = [
        'SAQ Sprint (Period 3): Explain one cause and one effect of the French and Indian War in 4-5 sentences.',
        'DBQ Micro-Task (Period 5): Evaluate how Civil War-era federal actions reshaped citizenship from 1861-1877.',
        'LEQ Builder (Period 7): Develop a thesis on continuity and change in U.S. foreign policy from 1890-1945.',
        'Source Lens (Period 2): Compare two colonial labor systems and identify one long-term economic consequence.',
        'Argument Drill (Period 8): Defend or refute the claim that domestic policy shifted most during 1960-1980.',
        'Evidence Check (Period 6): Cite two specific examples showing the impact of industrialization on migration.'
    ];

    challengeButton.addEventListener('click', () => {
        const randomIndex = Math.floor(Math.random() * prompts.length);
        challengeOutput.textContent = prompts[randomIndex];
    });
}

function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}
